"""Load, normalize, and persist YAML/JSON persona definitions."""

import json
import logging
import os
import re
import uuid
from typing import Any

import yaml
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Regex for validating persona IDs: lowercase ASCII letters, digits, hyphen,
# underscore. Length 1-64. Used both as a Pydantic validator and for
# defense-in-depth checks before any filesystem operation.
_PERSONA_ID_PATTERN = r"^[a-z0-9_-]{1,64}$"


class PersonaPersistenceError(RuntimeError):
    """Raised when persisted persona files cannot be updated."""


class Persona(BaseModel):
    """Validated persona definition used to build prompts and agent cards."""

    id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="Unique ID for the persona",
        pattern=_PERSONA_ID_PATTERN,
    )
    name: str = Field(..., description="Name of the persona")
    description: str = Field(default="", description="Description of the persona")
    personal_background: dict[str, Any] = Field(
        default_factory=dict, description="Personal background information"
    )
    language_style: dict[str, Any] = Field(
        default_factory=dict, description="Language style characteristics"
    )
    knowledge_domains: dict[str, Any] = Field(
        default_factory=dict, description="Knowledge domains and expertise"
    )
    interaction_samples: list[dict[str, Any]] = Field(
        default_factory=list, description="Sample interactions"
    )
    system_prompt: str | None = None

    def generate_system_prompt(self) -> str:
        """Build the default system prompt from structured persona fields."""
        if self.system_prompt:
            return self.system_prompt

        prompt_parts = []
        prompt_parts.append(f"You are {self.name}.")
        prompt_parts.append(self.description)

        # Voice and style hints keep generated responses aligned with the
        # persona file without requiring a hand-written system prompt.
        if self.language_style:
            prompt_parts.append("\nLanguage style:")
            if "tone" in self.language_style:
                prompt_parts.append(f"- Tone: {self.language_style['tone']}")
            if "vocabulary" in self.language_style:
                prompt_parts.append(
                    f"- Vocabulary: {self.language_style['vocabulary']}"
                )
            if "speaking_style" in self.language_style:
                prompt_parts.append(
                    f"- Speaking style: {self.language_style['speaking_style']}"
                )
            if "common_phrases" in self.language_style and isinstance(
                self.language_style["common_phrases"], list
            ):
                phrases = ", ".join(
                    f'"{phrase}"' for phrase in self.language_style["common_phrases"]
                )
                prompt_parts.append(f"- Frequently use phrases like: {phrases}")

        # Background entries are user-defined keys, so render them as labels
        # instead of assuming a fixed schema.
        if self.personal_background:
            background_parts = []
            for key, value in self.personal_background.items():
                background_parts.append(f"- {key.replace('_', ' ').title()}: {value}")
            if background_parts:
                prompt_parts.append("\nBackground:")
                prompt_parts.extend(background_parts)

        if self.knowledge_domains:
            prompt_parts.append("\nYou have knowledge and expertise in:")
            for domain, topics in self.knowledge_domains.items():
                if isinstance(topics, list):
                    topics_str = ", ".join(topics)
                    prompt_parts.append(
                        f"- {domain.replace('_', ' ').title()}: {topics_str}"
                    )

        prompt_parts.append(
            "\nYou have access to various tools through the Model Context Protocol (MCP). Use these tools when they would help you provide better responses or access information you don't have."
        )

        prompt_parts.append(
            "\nAlways stay in character and respond as this persona would, using their speaking style, knowledge, and background to inform your responses."
        )

        return "\n".join(prompt_parts)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Persona":
        """Create a Persona instance from a dictionary."""
        return cls(**data)


class PersonaManager:
    """Manage personas loaded from a filesystem directory."""

    def __init__(self, personas_dir: str):
        self.personas_dir = personas_dir
        self.personas: dict[str, Persona] = {}
        self._persona_files: dict[str, set[str]] = {}
        self._load_personas()

    def _load_personas(self) -> None:
        """Load all persona definitions from the personas directory."""
        if not os.path.exists(self.personas_dir):
            os.makedirs(self.personas_dir, exist_ok=True)
            return

        for filename in os.listdir(self.personas_dir):
            file_path = os.path.join(self.personas_dir, filename)
            if os.path.isfile(file_path) and (
                filename.endswith(".json")
                or filename.endswith(".yaml")
                or filename.endswith(".yml")
            ):
                try:
                    persona = self._load_persona_file(file_path)
                    if persona:
                        self.personas[persona.id] = persona
                        self._persona_files.setdefault(persona.id, set()).add(file_path)
                except Exception as e:
                    logger.warning("Error loading persona from %s: %s", file_path, e)

    def _load_persona_file(self, file_path: str) -> Persona | None:
        """Load a persona definition from a file."""
        try:
            with open(file_path, encoding="utf-8") as f:
                if file_path.endswith(".json"):
                    data = json.load(f)
                else:  # YAML file
                    data = yaml.safe_load(f)

                normalized_id = self._resolve_persona_id(data, file_path)
                if normalized_id is None:
                    return None
                data["id"] = normalized_id

                return Persona.from_dict(data)
        except Exception as e:
            logger.warning("Error loading persona file %s: %s", file_path, e)
            return None

    @staticmethod
    def _resolve_persona_id(data: dict[str, Any], file_path: str) -> str | None:
        """Resolve a regex-conformant persona id from file contents.

        If the file declares an ``id`` that already matches the canonical
        pattern, it is returned unchanged. If it declares an ``id`` that does
        not match (e.g., uppercase, dots, spaces from older files), the value
        is sanitized in place and the change is logged so the user can update
        the file. If no ``id`` is declared, the filename stem is sanitized.
        Returns ``None`` when no usable id can be produced; the file should
        then be skipped.
        """
        raw = data.get("id")
        if isinstance(raw, str) and re.match(_PERSONA_ID_PATTERN, raw):
            return raw

        if isinstance(raw, str) and raw:
            sanitized = re.sub(r"[^a-z0-9_-]", "-", raw.lower()).strip("-")[:64]
            if sanitized:
                logger.warning(
                    "Persona id %r in %s does not match %s; normalized to %r",
                    raw,
                    file_path,
                    _PERSONA_ID_PATTERN,
                    sanitized,
                )
                return sanitized

        base_name = os.path.basename(file_path)
        stem = os.path.splitext(base_name)[0]
        sanitized = re.sub(r"[^a-z0-9_-]", "-", stem.lower()).strip("-")[:64]
        if sanitized:
            return sanitized

        logger.warning("Skipping persona file %s: cannot derive a valid id", file_path)
        return None

    def get_persona(self, persona_id: str) -> Persona | None:
        """Get a persona by ID."""
        return self.personas.get(persona_id)

    def list_personas(self) -> list[dict[str, Any]]:
        """List all available personas."""
        return [
            {"id": persona.id, "name": persona.name, "description": persona.description}
            for persona in self.personas.values()
        ]

    def add_persona(self, persona_data: dict[str, Any]) -> Persona:
        """Add a new persona."""
        persona = Persona.from_dict(persona_data)
        self.personas[persona.id] = persona
        return persona

    def update_persona(
        self, persona_id: str, persona_data: dict[str, Any]
    ) -> Persona | None:
        """Update an existing persona."""
        if persona_id not in self.personas:
            return None

        persona_data["id"] = persona_id  # Keep the resource identity stable.
        persona = Persona.from_dict(persona_data)
        self.personas[persona_id] = persona
        return persona

    def delete_persona(self, persona_id: str) -> bool:
        """Delete a persona by ID."""
        if persona_id not in self.personas:
            return False

        try:
            self._delete_persona_files(persona_id)
        except OSError as exc:
            logger.exception("Error deleting persona files for %s", persona_id)
            raise PersonaPersistenceError(
                f"Error deleting persona files for {persona_id}"
            ) from exc

        del self.personas[persona_id]
        return True

    def _delete_persona_files(self, persona_id: str) -> None:
        """Delete persisted files associated with a persona."""
        root = os.path.abspath(self.personas_dir)
        candidates = set(self._persona_files.get(persona_id, set()))

        for file_path in candidates:
            abs_path = os.path.abspath(file_path)
            if os.path.commonpath([root, abs_path]) != root:
                logger.warning(
                    "Skipping persona file outside personas_dir: %s", file_path
                )
                continue
            if os.path.isfile(abs_path):
                os.remove(abs_path)

        self._persona_files.pop(persona_id, None)

    def save_persona(self, persona: Persona, format: str = "json") -> str:
        """Persist a persona using the canonical ``<id>.<format>`` filename."""
        if format not in ("json", "yaml"):
            raise ValueError("Format must be 'json' or 'yaml'")

        # Defense-in-depth: even though the Persona model already constrains
        # `id` via a regex, reject any value that looks like a path traversal
        # attempt or contains separator/null bytes before touching the FS.
        persona_id = persona.id
        if (
            not re.match(_PERSONA_ID_PATTERN, persona_id)
            or ".." in persona_id
            or "/" in persona_id
            or "\\" in persona_id
            or "\x00" in persona_id
        ):
            raise ValueError("Invalid persona id")

        filename = f"{persona_id}.{format}"
        file_path = os.path.join(self.personas_dir, filename)

        with open(file_path, "w", encoding="utf-8") as f:
            if format == "json":
                json.dump(persona.model_dump(), f, indent=2)
            else:
                yaml.dump(persona.model_dump(), f, default_flow_style=False)

        self._persona_files.setdefault(persona.id, set()).add(file_path)
        return file_path
